#!/usr/bin/env python3
"""Apply exact, fail-closed source edits required by the RMA-065 payload."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if text.count(old) != 1:
        raise SystemExit(f"expected exactly one source block in {path}: {old!r}")
    path.write_text(text.replace(old, new), encoding="utf-8", newline="\n")


def main() -> int:
    header = ROOT / "native/reachy_sim/include/reachy_sim.h"
    replace_once(
        header,
        """typedef enum ReachySimHealthFlag {\n    REACHY_SIM_HEALTH_FLAG_SLEEPING = UINT32_C(1) << 0,\n    REACHY_SIM_HEALTH_FLAG_MUJOCO_WARNING = UINT32_C(1) << 1\n} ReachySimHealthFlag;""",
        """typedef enum ReachySimHealthFlag {\n    REACHY_SIM_HEALTH_FLAG_SLEEPING = UINT32_C(1) << 0,\n    REACHY_SIM_HEALTH_FLAG_MUJOCO_WARNING = UINT32_C(1) << 1,\n    REACHY_SIM_HEALTH_FLAG_CONTACT_OVERLOAD = UINT32_C(1) << 2,\n    REACHY_SIM_HEALTH_FLAG_HARD_STOP = UINT32_C(1) << 3\n} ReachySimHealthFlag;""",
    )

    types = ROOT / "native/reachy_sim/src/reachy_sim_backend_mujoco/types_and_validation/part1.inc"
    replace_once(
        types,
        """#define REACHY_MUJOCO_KNOWN_HEALTH_FLAGS ((uint32_t)(\\\n    REACHY_SIM_HEALTH_FLAG_SLEEPING | REACHY_SIM_HEALTH_FLAG_MUJOCO_WARNING))""",
        """#define REACHY_MUJOCO_KNOWN_HEALTH_FLAGS ((uint32_t)(\\\n    REACHY_SIM_HEALTH_FLAG_SLEEPING | REACHY_SIM_HEALTH_FLAG_MUJOCO_WARNING | \\\n    REACHY_SIM_HEALTH_FLAG_CONTACT_OVERLOAD | REACHY_SIM_HEALTH_FLAG_HARD_STOP))""",
    )

    cmake = ROOT / "native/reachy_sim/CMakeLists.txt"
    cmake_text = cmake.read_text(encoding="utf-8")
    cmake_old = """            FILES\n                include/reachy_sim.h\n                include/reachy_sim_version.h"""
    cmake_new = """            FILES\n                include/reachy_sim.h\n                include/reachy_sim_state.h\n                include/reachy_sim_version.h"""
    if cmake_text.count(cmake_old) != 2:
        raise SystemExit("expected exactly two reachy_sim public header sets")
    cmake.write_text(
        cmake_text.replace(cmake_old, cmake_new),
        encoding="utf-8",
        newline="\n",
    )

    state_test = ROOT / "native/reachy_sim/tests/reachy_sim_mujoco_backend_test/part_state_payload.inc"
    replace_once(
        state_test,
        "REACHY_SIM_STATE_FORMAT_VERSION + 1U",
        "REACHY_SIM_DYNAMICS_STATE_FORMAT_VERSION + 1U",
    )

    cmake_text = cmake.read_text(encoding="utf-8")
    runner_marker = """if(REACHY_BUILD_MUJOCO_PROBE)
    add_subdirectory(feasibility)
endif()
"""
    runner_block = """if(BUILD_TESTING AND REACHY_BUILD_MUJOCO_BACKEND)
    add_executable(
        reachy_sim_dynamics_state_runner
        tests/reachy_sim_dynamics_state_runner.c
    )
    target_link_libraries(
        reachy_sim_dynamics_state_runner
        PRIVATE
            reachy_sim
    )
    target_compile_features(
        reachy_sim_dynamics_state_runner
        PRIVATE
            c_std_17
    )
    set_target_properties(
        reachy_sim_dynamics_state_runner
        PROPERTIES
            C_EXTENSIONS OFF
    )
    reachy_enable_strict_warnings(reachy_sim_dynamics_state_runner)
    reachy_enable_sanitizers(reachy_sim_dynamics_state_runner)
endif()

"""
    if cmake_text.count(runner_marker) != 1:
        raise SystemExit("CMake feasibility marker was not found exactly once")
    cmake.write_text(
        cmake_text.replace(runner_marker, runner_block + runner_marker),
        encoding="utf-8",
        newline="\n",
    )

    feasibility_cmake = ROOT / "native/reachy_sim/feasibility/CMakeLists.txt"
    feasibility_text = feasibility_cmake.read_text(encoding="utf-8")
    feasibility_marker = """endif()

if(REACHY_BUILD_MUJOCO_BACKEND)
"""
    benchmark_block = """    add_executable(
        reachy_mujoco_collision_benchmark_runner
        reachy_mujoco_collision_benchmark_runner.c
    )
    target_link_libraries(
        reachy_mujoco_collision_benchmark_runner
        PRIVATE
            reachy_external_mujoco
            m
    )
    target_compile_features(
        reachy_mujoco_collision_benchmark_runner
        PRIVATE
            c_std_17
    )
    set_target_properties(
        reachy_mujoco_collision_benchmark_runner
        PROPERTIES
            C_EXTENSIONS OFF
    )
    reachy_enable_strict_warnings(reachy_mujoco_collision_benchmark_runner)

"""
    if feasibility_text.count(feasibility_marker) != 1:
        raise SystemExit("feasibility CMake backend marker was not found exactly once")
    feasibility_cmake.write_text(
        feasibility_text.replace(feasibility_marker, benchmark_block + feasibility_marker),
        encoding="utf-8",
        newline="\n",
    )

    main_test = ROOT / "native/reachy_sim/tests/reachy_sim_mujoco_backend_test.c"
    main_test.write_text(
        """#include \"reachy_sim_state.h\"\n#include \"reachy_sim_mujoco_backend_test/part1.inc\"\n#include \"reachy_sim_mujoco_backend_test/part2.inc\"\n#define main reachy_sim_mujoco_existing_main\n#include \"reachy_sim_mujoco_backend_test/part3.inc\"\n#undef main\n#include \"reachy_sim_mujoco_backend_test/part_state_payload.inc\"\n#include \"reachy_sim_mujoco_backend_test/part_dynamics_state.inc\"\n\nint main(void)\n{\n    test_authoritative_state_payload();\n    test_dynamics_state_payload();\n    return reachy_sim_mujoco_existing_main();\n}\n""",
        encoding="utf-8",
        newline="\n",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
